from telegram import Update
from telegram.ext import CallbackContext
from utils.data_fetcher import fetch_ohlcv


async def test_command(update: Update, context: CallbackContext):
    symbol = "BTC/USDT"
    df = fetch_ohlcv(symbol=symbol, timeframe="1h", limit=2)  # последние 2 свечи по 1 часу

    if df is None or df.empty or len(df) < 2:
        await update.message.reply_text("Ошибка при получении данных с Bybit.")
        return

    price_start = df.iloc[0]["close"]
    price_end = df.iloc[1]["close"]
    change = ((price_end - price_start) / price_start) * 100
    arrow = "📈" if change > 0 else "📉"
    text = f"{symbol} {arrow} {change:.2f}% за последний час"

    await update.message.reply_text(text)
